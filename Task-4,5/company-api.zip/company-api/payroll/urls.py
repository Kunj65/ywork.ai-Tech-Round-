from django.urls import path
from . import views

urlpatterns = [
    path("departments/", views.add_department),
    path("employees/", views.add_employee),
    path("employees/all/", views.get_employees),
    path("employees/<int:employee_id>/", views.get_employee_by_id),
    path("employees/<int:employee_id>/update/", views.update_employee),
    path("employees/<int:employee_id>/delete/", views.delete_employee),
    path("departments/<int:department_id>/employees/", views.get_employees_by_department),
    path("employees/<int:employee_id>/increase-salary/", views.increase_salary),
    path("departments/<int:department_id>/total-salary/", views.get_total_salary_by_department),
]
