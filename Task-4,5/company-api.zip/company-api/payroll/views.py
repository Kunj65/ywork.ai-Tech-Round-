from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import Employee, Department


# ---------------------------
# Task 1: Add Department
# ---------------------------
@csrf_exempt
def add_department(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            name = data.get("name")
            if not name:
                return JsonResponse({"error": "name is required"}, status=400)

            dept = Department.objects.create(name=name)
            return JsonResponse({"id": dept.id, "name": dept.name})
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400) 


# ---------------------------
# Task 2: Add Employee
# ---------------------------
@csrf_exempt
def add_employee(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            name = data.get("name")
            departmentId = data.get("departmentId")
            baseSalary = data.get("baseSalary")

            if not (name and departmentId and baseSalary):
                return JsonResponse({"error": "name, departmentId, baseSalary required"}, status=400)

            dept = Department.objects.get(pk=departmentId)
            emp = Employee.objects.create(name=name, department=dept, baseSalary=baseSalary)
            return JsonResponse({"id": emp.id, "name": emp.name})
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)


# ---------------------------
# Task 3: Get All Employees
# ---------------------------
def get_employees(request):
    employees = Employee.objects.all().values("id", "name", "department__name", "baseSalary")
    return JsonResponse(list(employees), safe=False)


# ---------------------------
# Task 4: Update Employee
# ---------------------------
@csrf_exempt
def update_employee(request, employee_id):
    if request.method == "PUT":
        try:
            emp = Employee.objects.get(pk=employee_id)
            data = json.loads(request.body)

            emp.name = data.get("name", emp.name)
            if "departmentId" in data:
                emp.department = Department.objects.get(pk=data["departmentId"])
            emp.baseSalary = data.get("baseSalary", emp.baseSalary)
            emp.save()

            return JsonResponse({"message": "Employee updated successfully"})
        except Employee.DoesNotExist:
            return JsonResponse({"error": "Employee not found"}, status=404)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return JsonResponse({"error": "Invalid method"}, status=405)


# ---------------------------
# Task 5: Delete Employee
# ---------------------------
@csrf_exempt
def delete_employee(request, employee_id):
    if request.method == "DELETE":
        try:
            emp = Employee.objects.get(pk=employee_id)
            emp.delete()
            return JsonResponse({"message": "Employee deleted successfully"})
        except Employee.DoesNotExist:
            return JsonResponse({"error": "Employee not found"}, status=404)
    return JsonResponse({"error": "Invalid method"}, status=405)


# ---------------------------
# Task 6: Get Employee by ID
# ---------------------------
def get_employee_by_id(request, employee_id):
    try:
        emp = Employee.objects.get(pk=employee_id)
        return JsonResponse({
            "id": emp.id,
            "name": emp.name,
            "department": emp.department.name,
            "baseSalary": emp.baseSalary
        })
    except Employee.DoesNotExist:
        return JsonResponse({"error": "Employee not found"}, status=404)


# ---------------------------
# Task 7: Get Employees by Department
# ---------------------------
def get_employees_by_department(request, department_id):
    employees = Employee.objects.filter(department__id=department_id).values("id", "name", "baseSalary")
    return JsonResponse(list(employees), safe=False)


# ---------------------------
# Task 8: Increase Salary
# ---------------------------
@csrf_exempt
def increase_salary(request, employee_id):
    if request.method == "PUT":
        try:
            emp = Employee.objects.get(pk=employee_id) 
            data = json.loads(request.body)
            increment = data.get("increment", 0)
            emp.baseSalary += increment
            emp.save()
            return JsonResponse({"message": "Salary increased", "newSalary": emp.baseSalary})
        except Employee.DoesNotExist:
            return JsonResponse({"error": "Employee not found"}, status=404)
    return JsonResponse({"error": "Invalid method"}, status=405)


# ---------------------------
# Task 9: Get Total Salary by Department
# ---------------------------
def get_total_salary_by_department(request, department_id):
    employees = Employee.objects.filter(department__id=department_id)
    total_salary = sum(emp.baseSalary for emp in employees)
    return JsonResponse({"departmentId": department_id, "totalSalary": total_salary})
