from django.db import models
from django.utils import timezone


class Department(models.Model):
    name = models.CharField(max_length=100, default="")  # default empty string

    def __str__(self):
        return self.name


class Employee(models.Model):
    name = models.CharField(max_length=100, default="")  # avoid null issues
    department = models.ForeignKey(Department, on_delete=models.CASCADE, null=True, blank=True)
    baseSalary = models.FloatField(default=0.0)  # safe default salary
    created_at = models.DateTimeField(default=timezone.now)  # avoids migration prompt

    def __str__(self):
        return self.name
